#include <stdio.h>
#include <allegro5/allegro.h>
#include <allegro5/allegro_font.h>
#include <allegro5/allegro_ttf.h>
#include <allegro5/allegro_primitives.h>
#include <allegro5/allegro_image.h>
#include <math.h>

const float FPS = 100;  

const int SCREEN_W = 960;
const int SCREEN_H = 720;

const float THETA = M_PI/4;
const float RAIO_CAMPO_FORCA = 47;
const float RAIO_TIRO = 10;
const float RAIO_HP = 20;

const float VEL_TANQUE = 1.5;
const float PASSO_ANGULO = M_PI/90;
const float VEL_BALA = 4.0;

ALLEGRO_BITMAP *tanque_1 = NULL;
ALLEGRO_BITMAP *tanque_2 = NULL;
ALLEGRO_BITMAP *cenario = NULL;
ALLEGRO_BITMAP *escudo = NULL;
ALLEGRO_BITMAP *coracao = NULL;
ALLEGRO_BITMAP *vitoria_1 = NULL;
ALLEGRO_BITMAP *vitoria_2 = NULL;

ALLEGRO_FONT *vida = NULL;
ALLEGRO_FONT *numeros = NULL;
ALLEGRO_FONT *pause1 = NULL;
ALLEGRO_FONT *pause2 = NULL;

FILE *vitorias = NULL;

typedef struct Ponto {

	float x, y;

} Ponto;

typedef struct Tanque {

	Ponto centro;
	Ponto A;
	ALLEGRO_COLOR cor;
	//referente ao projétil
	Ponto centro_bala;

	float vel; 
	float angulo;
	float x_comp, y_comp;
	float vel_angular;
	int id_tanque;
	int vida;
	//referente ao projétil;
	int fogo;
	float vel_bala;
	int cooldown;
	int variavel;

} Tanque;

typedef struct Retangulo{

	Ponto quina1, quina2, quina3, quina4;
	Ponto distCentro, distCentro_bala;
	int id_ret;

} Retangulo;

typedef struct PowerUp{
	Ponto centro, distCentro;
	int pwp;
} PowerUp;

void desenhaCenario(PowerUp hp){

	al_draw_bitmap(cenario, 0, 0, 0);

	al_draw_filled_rectangle(170, (SCREEN_H/2) - 200 , 200, (SCREEN_H/2) + 200, al_map_rgb(90, 90, 90));

	al_draw_filled_rectangle((SCREEN_W/2) - 130, (SCREEN_H/2) - 150, (SCREEN_W/2) + 130, (SCREEN_H/2) + 150, al_map_rgb(90,90,90));

	al_draw_filled_rectangle((SCREEN_W)- 200, (SCREEN_H/2) - 200, (SCREEN_W)- 170, (SCREEN_H/2) + 200, al_map_rgb(90,90,90));

	if(hp.pwp == 1){
		al_draw_scaled_rotated_bitmap(coracao, 284, 253, hp.centro.x, hp.centro.y, 0.075, 0.075, 0, 0);
		al_draw_scaled_rotated_bitmap(escudo, 236, 236, hp.centro.x, hp.centro.y, 0.1, 0.1, 0, 0);
	}
}

void desenhaTanque(Tanque t){

	if(t.id_tanque == 1){
		al_draw_scaled_rotated_bitmap(tanque_1, 48, 64, t.centro.x, t.centro.y, 0.5, 0.5, t.angulo + (M_PI/2), 0);
		al_draw_scaled_rotated_bitmap(escudo, 236, 236, t.centro.x, t.centro.y, 0.2, 0.2, 0, 0);
	}
	else{
		al_draw_scaled_rotated_bitmap(tanque_2, 54.5, 64, t.centro.x, t.centro.y, 0.5, 0.5, t.angulo + (M_PI/2), 0);
		al_draw_tinted_scaled_rotated_bitmap(escudo, al_map_rgba_f(1, 0, 0, 0.5), 236, 236, t.centro.x, t.centro.y, 0.2, 0.2, 0, 0);
	}

	//al_draw_circle(t.centro_bala.x, t.centro_bala.y, RAIO_TIRO, t.cor, 1);
	if(t.fogo != 0){
		al_draw_tinted_scaled_rotated_bitmap(escudo, al_map_rgba_f(1, 1, 0, 0), 236, 236, t.centro_bala.x, t.centro_bala.y, 0.05, 0.05, 0, 0);
	}
	al_draw_filled_rectangle(t.centro.x - 40, t.centro.y - RAIO_CAMPO_FORCA - 20,
							 t.centro.x - 40 + (float)(t.vida*(80/6)), t.centro.y - RAIO_CAMPO_FORCA - 10, al_map_rgb(240, 0, 0));
	al_draw_scaled_rotated_bitmap(coracao, 284, 253, t.centro.x - 40, t.centro.y - RAIO_CAMPO_FORCA - 15, 0.05, 0.05, 0, 0);
	al_draw_textf(vida, al_map_rgb(255,255,255), t.centro.x - 40, t.centro.y - RAIO_CAMPO_FORCA - 30, ALLEGRO_ALIGN_CENTRE, "%i", t.vida);

	//barrinha de cooldown;
	if(t.cooldown != 0){
		al_draw_filled_rectangle(t.centro.x - 40, t.centro.y + RAIO_CAMPO_FORCA + 5,
							 	 t.centro.x - 40 + (float)(t.cooldown*0.8), t.centro.y + RAIO_CAMPO_FORCA + 5 + 10, al_map_rgb(255, 150, 0));
	}
}

void printaVitoria(Tanque t, int vencedor){
	if(t.id_tanque == 1){
		al_draw_scaled_rotated_bitmap(vitoria_1, 226, 225, SCREEN_W/2, SCREEN_H/2, 1, 1, 0, 0);
		al_draw_textf(numeros, al_map_rgb(0,0,0), SCREEN_W/2, SCREEN_H/2 + 105, ALLEGRO_ALIGN_CENTRE, "%i", vencedor);
	}
	else{
		al_draw_scaled_rotated_bitmap(vitoria_2, 226, 225, SCREEN_W/2, SCREEN_H/2, 1, 1, 0, 0);
		al_draw_textf(numeros, al_map_rgb(0,0,0), SCREEN_W/2, SCREEN_H/2 + 105, ALLEGRO_ALIGN_CENTRE, "%i", vencedor);
	}
}

void rotate(Ponto *P, float Angle){
	float x = P->x, y = P->y;

	P->x = (x * cos(Angle)) - (y * sin(Angle));
	P->y = (y * cos(Angle)) + (x * sin(Angle));
}

void rotacionaTanque(Tanque *t){

	if(t->vel_angular != 0){
		rotate(&t->A, t->vel_angular);
		
		t->angulo += t->vel_angular;

		t->x_comp = cos(t->angulo);
		t->y_comp = sin(t->angulo);
	}
}

void atualizaTanque(Tanque *t){
	t->centro.y += t->vel * t->y_comp;
	t->centro.x += t->vel * t->x_comp;
}

void quinas(Tanque *t, Ponto quina, int a, int b){
	float distQuina_x = 0, distQuina_y = 0, distQuina = 0;
	distQuina_x = abs(t->centro.x - quina.x);
	distQuina_y = abs(t->centro.y - quina.y);
	distQuina = hypot(distQuina_x, distQuina_y);

	if(distQuina <= RAIO_CAMPO_FORCA){
		t->centro.x = quina.x + (a * (RAIO_CAMPO_FORCA * (distQuina_x/distQuina)));
		t->centro.y = quina.y + (b * (RAIO_CAMPO_FORCA * (distQuina_y/distQuina)));
	}
}

void obstaculos(Tanque *t, Retangulo r){
	//lados esquerdo e direito + quinas
	if(t->centro.y > r.quina1.y && t->centro.y < r.quina3.y){
		if(t->centro.x < (r.quina1.x + r.quina2.x)/2){
			if(t->vel * t->x_comp >= 0){
				t->centro.x = r.quina1.x - RAIO_CAMPO_FORCA;
			}
		}
		else if(t->vel * t->x_comp <= 0){
			t->centro.x = r.quina2.x + RAIO_CAMPO_FORCA;
		}
	}
	if(r.distCentro.y <= (SCREEN_H/2 - r.quina1.y) + RAIO_CAMPO_FORCA 
	   && r.distCentro.y >= (SCREEN_H/2 - r.quina1.y) 
	   && r.distCentro.x >= (r.quina2.x - r.quina1.x)/2){
		if(t->centro.y < SCREEN_H/2){
			if(t->centro.x < r.quina1.x){
				quinas(t, r.quina1, -1, -1);
			}
			else{
				quinas(t,r.quina2, 1, -1);
			}
		}
		else if(t->centro.x < r.quina1.x){
			quinas(t, r.quina3, -1, 1);
		}
		else{
			quinas(t, r.quina4, 1, 1);
		}
	}
	if(r.distCentro.y <= (SCREEN_H/2 - r.quina1.y) + RAIO_CAMPO_FORCA){
		if(t->centro.x > r.quina1.x && t->centro.x < r.quina2.x){
			if(t->centro.y < SCREEN_H/2){
				if(t->vel * t->y_comp >= 0){
					t->centro.y = r.quina1.y - RAIO_CAMPO_FORCA;
				}
			}
			else if(t->vel * t->y_comp <= 0){
				t->centro.y = r.quina3.y + RAIO_CAMPO_FORCA;
			}
		}
	}
}

void verifica(Tanque *t1, Tanque *t2, Retangulo r1, Retangulo r2, Retangulo r3, PowerUp *hp){

	rotacionaTanque(t1);
	
	float distX = t1->centro.x - t2->centro.x;
	float distY = t1->centro.y - t2->centro.y;
	float dist = hypot(distX, distY);
	float P_t1x = 0, P_t1y = 0, P_t2x = 0, P_t2y = 0, distPWP = 0;

	r1.distCentro.x = abs(t1->centro.x - (r1.quina1.x + r1.quina2.x)/2);
	r1.distCentro.y = abs(t1->centro.y - SCREEN_H/2);

	r2.distCentro.x = abs(t1->centro.x - (r2.quina1.x + r2.quina2.x)/2);
	r2.distCentro.y = abs(t1->centro.y - (SCREEN_H/2));

	r3.distCentro.x = abs(t1->centro.x - (r3.quina1.x + r3.quina2.x)/2);
	r3.distCentro.y = abs(t1->centro.y - (SCREEN_H/2));

	if(hp->pwp == 1){
		hp->distCentro.x = abs(t1->centro.x - hp->centro.x);
		hp->distCentro.y = abs(t1->centro.y - hp->centro.y);
		distPWP = hypot(hp->distCentro.x, hp->distCentro.y);
	}

	if(distPWP <= RAIO_CAMPO_FORCA + RAIO_HP && hp->pwp == 1){
		t1->vida++;
		hp->pwp--;
	}
	
	if(dist <= RAIO_CAMPO_FORCA * 2){

		P_t1x = t1->centro.x;
		P_t1y = t1->centro.y;
		P_t2x = t2->centro.x;
		P_t2y = t2->centro.y;

		t1->centro.x = P_t2x + ((RAIO_CAMPO_FORCA*2) * (distX/dist));
		t1->centro.y = P_t2y + ((RAIO_CAMPO_FORCA*2) * (distY/dist));
		t2->centro.x = P_t1x - ((RAIO_CAMPO_FORCA*2) * (distX/dist));
		t2->centro.y = P_t1y - ((RAIO_CAMPO_FORCA*2) * (distY/dist));
	}

	//lateral esquerda;
	if(t1->centro.x <= RAIO_CAMPO_FORCA){
		t1->centro.x = RAIO_CAMPO_FORCA;
	}
	//lateral direita;
	if(t1->centro.x >= SCREEN_W - RAIO_CAMPO_FORCA){
		t1->centro.x = SCREEN_W - RAIO_CAMPO_FORCA;
	}
	//lado superior;
	if(t1->centro.y <= RAIO_CAMPO_FORCA){
		t1->centro.y = RAIO_CAMPO_FORCA;
	}
	//lado inferior;
	if(t1->centro.y >= SCREEN_H - RAIO_CAMPO_FORCA){
		t1->centro.y = SCREEN_H - RAIO_CAMPO_FORCA;
	}
	
	//OBSTÁCULO 1;
	if(r1.distCentro.x <= (r1.quina2.x - r1.quina1.x)/2 + RAIO_CAMPO_FORCA){
		obstaculos(t1, r1);
	}
	if(r2.distCentro.x <= (r2.quina2.x - r2.quina1.x)/2 + RAIO_CAMPO_FORCA){
		obstaculos(t1, r2);
	}
	if(r3.distCentro.x <= (r3.quina2.x - r3.quina1.x)/2 + RAIO_CAMPO_FORCA){
		obstaculos(t1, r3);
	}
}

void atualizaBala(Tanque *t){
	if(t->fogo == 0){
		t->centro_bala.x = t->A.x + t->centro.x;
		t->centro_bala.y = t->A.y + t->centro.y;
	}
}

void atualizaTiro(Tanque *t1, Tanque *t2, float x_comp, float y_comp, Retangulo r1, Retangulo r2, Retangulo r3){

	if(t1->fogo == 1){
		
		t1->vel_bala = VEL_BALA;
		t1->centro_bala.x -= t1->vel_bala * x_comp;
		t1->centro_bala.y -= t1->vel_bala * y_comp;
		
		float distX = t1->centro_bala.x - t2->centro.x;
		float distY = t1->centro_bala.y - t2->centro.y;
		float dist = hypot(distX, distY);

		r1.distCentro_bala.x = abs(t1->centro_bala.x - (r1.quina1.x + r1.quina2.x)/2);
		r1.distCentro_bala.y = abs(t1->centro_bala.y - SCREEN_H/2);

		r2.distCentro_bala.x = abs(t1->centro_bala.x - (r2.quina1.x + r2.quina2.x)/2);
		r2.distCentro_bala.y = abs(t1->centro_bala.y - SCREEN_H/2);

		r3.distCentro_bala.x = abs(t1->centro_bala.x - (r3.quina1.x + r3.quina2.x)/2);
		r3.distCentro_bala.y = abs(t1->centro_bala.y - SCREEN_H/2);

		
		if(t1->variavel == 1){
			if(t1->centro_bala.x <= RAIO_TIRO || t1->centro_bala.x >= SCREEN_W - RAIO_TIRO){
				t1->fogo = 0;
				t1->centro_bala.x = t1->A.x;
				t1->centro_bala.y = t1->A.y;
				t1->vel_bala = 0;
				t1->variavel = 0;
			}
			if(t1->centro_bala.x <= RAIO_TIRO || t1->centro_bala.x >= SCREEN_W - RAIO_TIRO){
				t1->fogo = 0;
				t1->centro_bala.x = t1->A.x;
				t1->centro_bala.y = t1->A.y;
				t1->vel_bala = 0;
				t1->variavel = 0;
			}
			if(t1->centro_bala.y <= RAIO_TIRO || t1->centro_bala.y >= SCREEN_H - RAIO_TIRO){
				t1->fogo = 0;
				t1->centro_bala.x = t1->A.x;
				t1->centro_bala.y = t1->A.y;
				t1->vel_bala = 0;
				t1->variavel = 0;
			}
			if(dist <= RAIO_CAMPO_FORCA + RAIO_TIRO){
				t1->fogo = 0;
				t1->centro_bala.x = t1->A.x;
				t1->centro_bala.y = t1->A.y;
				t1->vel_bala = 0;
				t2->vida--;
				t1->variavel = 0;
			}
		}
		
		else{
			//
			if(t1->centro_bala.y <= RAIO_TIRO || t1->centro_bala.y >= SCREEN_H - RAIO_TIRO){
				t1->fogo = 0;
				t1->centro_bala.x = t1->A.x;
				t1->centro_bala.y = t1->A.y;
				t1->vel_bala = 0;
			}
			//
			if(t1->centro_bala.x <= RAIO_TIRO || t1->centro_bala.x >= SCREEN_W - RAIO_TIRO){
				t1->fogo = 0;
				t1->centro_bala.x = t1->A.x;
				t1->centro_bala.y = t1->A.y;
				t1->vel_bala = 0;
			}
			//
			if(t1->centro_bala.y <= RAIO_TIRO || t1->centro_bala.y >= SCREEN_H - RAIO_TIRO){
				t1->fogo = 0;
				t1->centro_bala.x = t1->A.x;
				t1->centro_bala.y = t1->A.y;
				t1->vel_bala = 0;
			}
			//
			if(dist <= RAIO_CAMPO_FORCA + RAIO_TIRO){
				t1->fogo = 0;
				t1->centro_bala.x = t1->A.x;
				t1->centro_bala.y = t1->A.y;
				t1->vel_bala = 0;
				t2->vida--;
			}
		
		//OBSTÁCULO 1;
			if(r1.distCentro_bala.x <= (r1.quina2.x - r1.quina1.x)/2 + RAIO_TIRO){
				if(r1.distCentro_bala.y <= (r1.quina3.y - SCREEN_H/2) + RAIO_TIRO){
					t1->fogo = 0;
					t1->centro_bala.x = t1->A.x;
					t1->centro_bala.y = t1->A.y;
					t1->vel_bala = 0;
				}
			}
		//OBSTÁCULO 2;
			if(r2.distCentro_bala.x <= (r2.quina2.x - r2.quina1.x)/2 + RAIO_TIRO){
				if(r2.distCentro_bala.y <= (r2.quina3.y - SCREEN_H/2) + RAIO_TIRO){
					t1->fogo = 0;
					t1->centro_bala.x = t1->A.x;
					t1->centro_bala.y = t1->A.y;
					t1->vel_bala = 0;
				}
			}
		//OBSTÁCULO 3;
			if(r3.distCentro_bala.x <= (r3.quina2.x - r3.quina1.x)/2 + RAIO_TIRO){
				if(r3.distCentro_bala.y <= (r3.quina3.y - SCREEN_H/2) + RAIO_TIRO){
					t1->fogo = 0;
					t1->centro_bala.x = t1->A.x;
					t1->centro_bala.y = t1->A.y;
					t1->vel_bala = 0;
				}
			}
		}
	}
}

void initPowerUp(PowerUp *hp){
	srand(time(NULL));
	int a = rand()%2;
	if(a == 0){
		hp->centro.x = SCREEN_W/2 - 190;
		hp->centro.y = 20 + rand()%681;
	}
	else{
		hp->centro.x = SCREEN_W/2 + 190;
		hp->centro.y = 20 + rand()%681;
	}
}

void initRet(Retangulo *r){
	r->distCentro.x = 0;
	r->distCentro.y = 0;
	r->distCentro_bala.x = 0;
	r->distCentro_bala.y = 0;
	if(r->id_ret == 1){
		//170, (SCREEN_H/2) - 200 , 200, (SCREEN_H/2) + 200
		r->quina1.x = 170, r->quina1.y = (SCREEN_H/2) - 200;
		r->quina2.x = 200, r->quina2.y = (SCREEN_H/2) - 200;
		r->quina3.x = 170, r->quina3.y = (SCREEN_H/2) + 200;
		r->quina4.x = 200, r->quina4.y = (SCREEN_H/2) + 200;
	}
	else if(r->id_ret == 2){
		//(SCREEN_W/2) - 130, (SCREEN_H/2) - 150, (SCREEN_W/2) + 130, (SCREEN_H/2) + 150
		r->quina1.x = (SCREEN_W/2) - 130, r->quina1.y = (SCREEN_H/2) - 150;
		r->quina2.x = (SCREEN_W/2) + 130, r->quina2.y = (SCREEN_H/2) - 150;
		r->quina3.x = (SCREEN_W/2) - 130, r->quina3.y = (SCREEN_H/2) + 150;
		r->quina4.x = (SCREEN_W/2) + 130, r->quina4.y = (SCREEN_H/2) + 150;
	}
	else{
		//(SCREEN_W)- 200, (SCREEN_H/2) - 200, (SCREEN_W)- 170, (SCREEN_H/2) + 200
		r->quina1.x = SCREEN_W - 200, r->quina1.y = (SCREEN_H/2) - 200;
		r->quina2.x = SCREEN_W - 170, r->quina2.y = (SCREEN_H/2) - 200;
		r->quina3.x = SCREEN_W - 200, r->quina3.y = (SCREEN_H/2) + 200;
		r->quina4.x = SCREEN_W - 170, r->quina4.y = (SCREEN_H/2) + 200;
	}
}

void initTanque(Tanque *t){

	if(t->id_tanque == 1){
		t->centro.x = SCREEN_W/9;
		t->centro.y = SCREEN_H/2;
		t->cor = al_map_rgb(255, 0, 0);
	}
	else{
		t->centro.x = SCREEN_W - (SCREEN_W/9);
		t->centro.y = SCREEN_H/2;
		t->cor = al_map_rgb(0, 0, 255);
	}

	t->A.x = 0;
	t->A.y = -RAIO_CAMPO_FORCA;

	float alpha = M_PI/2 - THETA;

	t->vel = 0;
	t->angulo = M_PI/2;
	t->x_comp = cos(t->angulo);
	t->y_comp = sin(t->angulo);
	t->vel_angular = 0;
	t->variavel = 0;

	//referente ao projétil;
	
	t->centro_bala.x = t->A.x + t->centro.x;
	t->centro_bala.y = t->A.y + t->centro.y;
	
	t->fogo = 0;
	t->vel_bala = 0;
	t->cooldown = 0;
	t->vida = 6;
}

int main(int argc, char **argv){
	
	ALLEGRO_DISPLAY *display = NULL;
	ALLEGRO_EVENT_QUEUE *event_queue = NULL;
	ALLEGRO_TIMER *timer = NULL;
   
	//----------------------- rotinas de inicializacao ---------------------------------------
    
	//inicializa o Allegro
	if(!al_init()) {
		fprintf(stderr, "failed to initialize allegro!\n");
		return -1;
	}
	
    //inicializa o módulo de primitivas do Allegro
    if(!al_init_primitives_addon()){
		fprintf(stderr, "failed to initialize primitives!\n");
        return -1;
    }	
	
	//inicializa o modulo que permite carregar imagens no jogo
	if(!al_init_image_addon()){
		fprintf(stderr, "failed to initialize image module!\n");
		return -1;
	}
   
	//cria um temporizador que incrementa uma unidade a cada 1.0/FPS segundos
    timer = al_create_timer(1.0 / FPS);
    if(!timer) {
		fprintf(stderr, "failed to create timer!\n");
		return -1;
	}
 
	//cria uma tela com dimensoes de SCREEN_W, SCREEN_H pixels
	display = al_create_display(SCREEN_W, SCREEN_H);
	if(!display) {
		fprintf(stderr, "failed to create display!\n");
		al_destroy_timer(timer);
		return -1;
	}

	//instala o teclado
	if(!al_install_keyboard()) {
		fprintf(stderr, "failed to install keyboard!\n");
		return -1;
	}

	//inicializa o modulo allegro que carrega as fontes
	al_init_font_addon();
	al_init_ttf_addon();

	//inicializa o modulo allegro que entende arquivos tff de fontes
	if(!al_init_ttf_addon()) {
		fprintf(stderr, "failed to load tff font module!\n");
		return -1;
	}
	
	//carrega o arquivo arial.ttf da fonte Arial e define que sera usado o tamanho 32 (segundo parametro)
    ALLEGRO_FONT *size_32 = al_load_font("arial.ttf", 32, 1);   
	if(size_32 == NULL) {
		fprintf(stderr, "font file does not exist or cannot be accessed!\n");
	}

 	//cria a fila de eventos
	event_queue = al_create_event_queue();
	if(!event_queue) {
		fprintf(stderr, "failed to create event_queue!\n");
		al_destroy_display(display);
		return -1;
	}

	//registra na fila os eventos de tela (ex: clicar no X na janela)
	al_register_event_source(event_queue, al_get_display_event_source(display));
	//registra na fila os eventos de tempo: quando o tempo altera de t para t+1
	al_register_event_source(event_queue, al_get_timer_event_source(timer));
	//registra na fila os eventos de teclado (ex: pressionar uma tecla)
	al_register_event_source(event_queue, al_get_keyboard_event_source());  	

	//cria o tanque 1 e tanque 2;
	Tanque t1;
	Tanque t2;
	t1.id_tanque = 1;
	t2.id_tanque = 2;
	tanque_1 = al_load_bitmap("tank-1.png");
	tanque_2 = al_load_bitmap("tank-13.png");
	cenario = al_load_bitmap("moss.jpg");
	escudo = al_load_bitmap("energy-shield-png-4.png");
	coracao = al_load_bitmap("coracao.png");
	vida = al_load_font("data-latin.ttf", 22, 0);
	numeros = al_load_font("bahnschrift.ttf", 48, 0);
	pause1 = al_load_font("bahnschrift.ttf", 48, 0);
	pause2 = al_load_font("bahnschrift.ttf", 24, 0);
	vitoria_1 = al_load_bitmap("player1.png");
	vitoria_2 = al_load_bitmap("player2.png");

	int vitorias_1 = 0, vitorias_2 = 0;

	vitorias = fopen("vitorias.txt", "r");
	fscanf(vitorias, "%i %i", &vitorias_1, &vitorias_2);
	fclose(vitorias);

	Retangulo r1, r2, r3;
	r1.id_ret = 1;
	r2.id_ret = 2;
	r3.id_ret = 3;

	PowerUp hp;
	hp.pwp = 0;

	initTanque(&t1);
	initTanque(&t2);

	initRet(&r1);
	initRet(&r2);
	initRet(&r3);

	//variáveis que armazenam o x_comp e o y_comp do atirador;
	float x1_comp = 0, y1_comp = 0, x2_comp = 0, y2_comp = 0;

	//inicia o temporizador
	al_start_timer(timer);
	
	//variáveis pertencentes ao while;
	int playing = 1, a = 1;
	int count = 0;

	while(playing) {
		ALLEGRO_EVENT ev;
		//espera por um evento e o armazena na variavel de evento ev
		al_wait_for_event(event_queue, &ev);

		//se o tipo de evento for um evento do temporizador, ou seja, se o tempo passou de t para t+1
		if(ev.type == ALLEGRO_EVENT_TIMER) {

			desenhaCenario(hp);

		    if(t1.vida <= 2 || t2.vida <= 2){
				if((int)(al_get_timer_count(timer)/FPS) %45 == 1 && hp.pwp == 0){
					fprintf(stderr, "%i", hp.pwp);
					hp.pwp = 1;
					initPowerUp(&hp);
				}				
			}

			atualizaTanque(&t1);
			atualizaTanque(&t2);

			desenhaTanque(t1);
			desenhaTanque(t2);

			atualizaBala(&t1);
			atualizaBala(&t2);

			atualizaTiro(&t1, &t2, x1_comp, y1_comp, r1, r2, r3);
			atualizaTiro(&t2, &t1, x2_comp, y2_comp, r1, r2, r3);

			verifica(&t1, &t2, r1, r2, r3, &hp);
			verifica(&t2, &t1, r1, r2, r3, &hp);

			if(t1.cooldown != 0){
				t1.cooldown--;
			}
			if(t2.cooldown != 0){
				t2.cooldown--;
			}

			//atualiza a tela (quando houver algo para mostrar)
			al_flip_display();
			
			if(al_get_timer_count(timer)%(int)FPS == 0)
				printf("\n%d segundos se passaram...", (int)(al_get_timer_count(timer)/FPS));
		}
		if(t1.vida == 0 || t2.vida == 0){
			playing = 0;
		}
	
		//se o tipo de evento for o fechamento da tela (clique no x da janela)
		else if(ev.type == ALLEGRO_EVENT_DISPLAY_CLOSE) {
			playing = 0;
			a = 0;
		}

		//se o tipo de evento for um pressionar de uma tecla
		else if(ev.type == ALLEGRO_EVENT_KEY_DOWN) {
			//imprime qual tecla foi
			printf("\ncodigo tecla: %d", ev.keyboard.keycode);

			switch(ev.keyboard.keycode){

				//TANQUE 1;
				case ALLEGRO_KEY_W:

					t1.vel -= VEL_TANQUE;
				break;

				case ALLEGRO_KEY_S:

					t1.vel += VEL_TANQUE;
				break;

				case ALLEGRO_KEY_D:

					t1.vel_angular += PASSO_ANGULO;
				break;

				case ALLEGRO_KEY_A:

					t1.vel_angular -= PASSO_ANGULO;
				break;

				case ALLEGRO_KEY_Q:
					
					if(t1.fogo == 0 && t1.cooldown == 0){
						t1.fogo = 1;
						t1.cooldown = 100;
						x1_comp = t1.x_comp;
						y1_comp = t1.y_comp;
					}
				break;

				case ALLEGRO_KEY_I:
					if(t1.variavel == 0){
						t1.variavel = 1;
					}
					else{
						printf("failed");
					}
				break;
				 
				//TANQUE 2;
				case ALLEGRO_KEY_PAD_8:
				
					t2.vel -= VEL_TANQUE;
				break;

				case ALLEGRO_KEY_PAD_5:

					t2.vel += VEL_TANQUE;
				break;

				case ALLEGRO_KEY_PAD_6:

					t2.vel_angular += PASSO_ANGULO;
				break;

				case ALLEGRO_KEY_PAD_4:

					t2.vel_angular -= PASSO_ANGULO;
				break;
				
			}
		}
		else if(ev.type == ALLEGRO_EVENT_KEY_UP) {
			//imprime qual tecla foi
			printf("\ncodigo tecla: %d", ev.keyboard.keycode);

			switch(ev.keyboard.keycode){

				case ALLEGRO_KEY_W:

					t1.vel += VEL_TANQUE;

				break;

				case ALLEGRO_KEY_S:

					t1.vel -= VEL_TANQUE;

				break;

				case ALLEGRO_KEY_D:

					t1.vel_angular -= PASSO_ANGULO;
				
				break;

				case ALLEGRO_KEY_A:

					t1.vel_angular += PASSO_ANGULO;

				break;

				//TANQUE 2;
				case ALLEGRO_KEY_PAD_8:

					t2.vel += VEL_TANQUE;

				break;

				case ALLEGRO_KEY_PAD_5:

					t2.vel -= VEL_TANQUE;

				break;

				case ALLEGRO_KEY_PAD_6:

					t2.vel_angular -= PASSO_ANGULO;
				
				break;

				case ALLEGRO_KEY_PAD_4:

					t2.vel_angular += PASSO_ANGULO;

				break;

				case ALLEGRO_KEY_PAD_7:

					if(t2.fogo == 0 && t2.cooldown == 0){
						t2.fogo = 1;
						t2.cooldown = 100;
						x2_comp = t2.x_comp;
						y2_comp = t2.y_comp;
					}
				break;					
			}

		}

	} //fim do while

	if(t2.vida == 0){
		vitorias_1++;
		vitorias = fopen("vitorias.txt", "w");
		fprintf(vitorias, "%i %i", vitorias_1, vitorias_2);
	}

	if(t1.vida == 0){
		vitorias_2++;
		vitorias = fopen("vitorias.txt", "w");
		fprintf(vitorias, "%i %i", vitorias_1, vitorias_2);
	}

	while(a){
		
		ALLEGRO_EVENT ev;

		al_wait_for_event(event_queue, &ev);

		if(t1.vida == 0){
			printaVitoria(t2, vitorias_2);
		}
		
		if(t2.vida == 0){
			printaVitoria(t1, vitorias_1);
		}

		al_flip_display();

		if(ev.type == ALLEGRO_EVENT_KEY_DOWN){
			switch(ev.keyboard.keycode){
				case ALLEGRO_KEY_PAD_ENTER:
					a = 0;
			}
		}
		else if(ev.type == ALLEGRO_EVENT_DISPLAY_CLOSE) {
			a = 0;
		}
	}
     
	//procedimentos de fim de jogo (fecha a tela, limpa a memoria, etc)
	
 
	al_destroy_timer(timer);
	al_destroy_display(display);
	al_destroy_event_queue(event_queue);
   
 
	return 0;
}